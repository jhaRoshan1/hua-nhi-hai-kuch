package com.cg.bookstore.exception;

public class UserDetailsNotFound {

}
