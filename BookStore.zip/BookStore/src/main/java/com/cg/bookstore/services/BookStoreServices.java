package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exception.CustomerDetailsNotFound;

public interface BookStoreServices {
Customer acceptCustomerDetails(Customer customer);
Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFound;
List<Customer> getAllCustomerDetails();
Customer updateCustomerDetails(Customer customer)throws CustomerDetailsNotFound;
}
