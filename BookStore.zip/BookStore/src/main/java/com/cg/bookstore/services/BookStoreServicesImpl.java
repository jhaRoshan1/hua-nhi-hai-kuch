package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.daoservices.CustomerDAO;
import com.cg.bookstore.exception.CustomerDetailsNotFound;
@Component("bookServices")
public class BookStoreServicesImpl implements BookStoreServices {
	
	@Autowired
	private CustomerDAO customerDAO;
	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		return customerDAO.save(customer);
	}
	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFound {	
 return customerDAO.findById(customerId).orElseThrow(()->new CustomerDetailsNotFound("Customer details not found"+customerId));
	}
	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDAO.findAll();
	}
	@Override
	public Customer updateCustomerDetails(Customer customer) {
		customerDAO.save(customer);
		return customer;
	}

}
